All files present on these folders are already on the "other smali" folder.

I've just left these here to be easier to spot which files have 0x10XXXXXX or 0x11XXXXXX values which, most likely, are content resources values that must match the original ones present on SystemUI.

So the goal is to edit theses files on "the other smali folder", before copying them to your original SystemUI smali folder, and afterwards copy/paste them to the original SystemUI, thus replacing the original files.

If you fail to do this, you'll end up with weird stuff on your recompiled SystemUI or, even worse, your device won't boot after trying to implement these MODs.
