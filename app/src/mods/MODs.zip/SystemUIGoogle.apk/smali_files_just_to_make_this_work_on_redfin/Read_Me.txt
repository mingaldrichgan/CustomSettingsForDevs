The files included on this folder are needed in order to get this MOD working on redfin (Pixel 5).

It's still a mistery to me why they don't work since they're working on every other pixel model.

This makes Network Traffic unavailable on Satus Bar, but it's sill available on QS Header...