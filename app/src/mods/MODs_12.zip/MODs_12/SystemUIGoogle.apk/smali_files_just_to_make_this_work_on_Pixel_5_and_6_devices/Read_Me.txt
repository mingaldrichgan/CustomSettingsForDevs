The files included on this folder are needed in order to get this MOD working on Pixel 5 and Pixel 6 models.

It's still a mistery to me why they don't work since they're working on every other Pixel 3 and 4 models.

This makes Network Traffic unavailable on Satus Bar, but it's sill available on QS Header...