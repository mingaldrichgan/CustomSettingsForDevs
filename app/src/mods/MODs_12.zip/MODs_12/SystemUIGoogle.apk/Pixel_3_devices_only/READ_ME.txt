Originally com\android\systemui\statusbar\policy and com\android\systemui\statusbar\tv were on smali folder, and not, on smali_classes2 folder.

Those folders need to be moved into smali_classes2 folder from the original one and the clock smali files have to be replaced, by the modded ones, in order to get the clock customization working.